#!/bin/bash
/opt/hud-menu/hud-menu-service.py &
/opt/hud-menu/hud-menu.py
exit